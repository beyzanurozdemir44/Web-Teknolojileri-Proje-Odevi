<?php
$user = "g211210072@sakarya.edu.tr";
$pass = "g211210072";
?>